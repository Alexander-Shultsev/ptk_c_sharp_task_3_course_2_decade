﻿using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Collections.Generic;

namespace task_2
{
    class Lessons
    {
        string[] people = { "Tom", "Bob", "Sam", "Tim", "Tomas", "Bill" };

        public class Person
        {
            public string name { get; set; }
            public int age { get; set; }
        }

        public Lessons()
        {

            //var people = new List<Person>
            //{
            //    new Person ("Tom", 23),
            //    new Person ("Bob", 27),
            //    new Person ("Sam", 29),
            //    new Person ("Alice", 24)
            //};

            //Console.Write(person.name);

            //var values = people.Where(j => j.ToUpper().StartsWith("T")).OrderByDescending(p => p);

            //foreach (var elem in values)
            //{
            //    Console.Write(elem);
            //}
        }

        
    }
}
