﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Task9 getData = new Task9();
            //Lessons getData = new Lessons();

            Console.ReadKey();
        }
    }
}
