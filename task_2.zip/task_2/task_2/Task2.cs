﻿using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net.Http;
namespace task_2
{
    class Task2
    {
        HttpClient client;
        string responseBody;

        public Task2()
        {
            client = new HttpClient();
            Get();
        }

        public async void Get()
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync("https://data.townofcary.org/api/records/1.0/search/?dataset=points-of-interest&q=&facet=owner&facet=owntype&facet=featurecode&facet=descript");
                responseBody = await response.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine(e);
            }

            JObject objectData = JObject.Parse(responseBody);

            var data = objectData["records"].Select(elem => new {
                DatasetID = (string)elem["datasetid"],
                Recordid = (string)elem["recordid"],
                Fields = new
                {
                    Featurecode = (string)elem["fields"]["featurecode"],
                    Name = (string)elem["fields"]["name"],
                    GeoShape = new
                    {
                        Coordinates = elem["fields"]["geo_shape"]["coordinates"].Select(i => (double)i).ToArray(),
                        Type = (string)elem["fields"]["geo_shape"]["type"],
                    },
                    GeoPoint2d = elem["fields"]["geo_point_2d"].Select(i => (double)i).ToArray(),
                    Owner = (string)elem["fields"]["owner"],
                    Owntype = (string)elem["fields"]["owntype"],
                    Fulladdr = (string)elem["fields"]["fulladdr"],
                    Descript = (string)elem["fields"]["descript"],
                },
                Geometry = new
                {
                    Type = (string)elem["geometry"]["type"],
                    Coordinates = elem["geometry"]["coordinates"].Select(i => (double)i).ToArray(),
                },
                RecordTimestamp = (DateTime)elem["record_timestamp"],
            }).ToList();

            var expression = data.Where(i => i.Fields.Name.Contains("Middle "));

            foreach (var i in expression)
            {
                Console.WriteLine(i);
            }
        }
    }
}
