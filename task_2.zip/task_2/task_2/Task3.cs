﻿using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net.Http;

namespace task_2
{
    class Task3
    {
        HttpClient client;
        string responseBody;

        public Task3()
        {
            client = new HttpClient();
            Get();
        }

        public async void Get()
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync("https://data.townofcary.org/api/records/1.0/search/?dataset=annexations&q=&facet=gisprod1_gis_adopp_annexations_status&facet=gisprod1_gis_adopp_annexations_effectivedate");
                responseBody = await response.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine(e);
            }

            JObject objectData = JObject.Parse(responseBody);

            var data = objectData["records"].Select(elem => new {
                DatasetID = (string)elem["datasetid"],
                Recordid = (string)elem["recordid"],
                Fields = new
                {
                    Gisprod1GisAdoppAnnexationsRealid = (string)elem["fields"]["gisprod1_gis_adopp_annexations_realid"],
                    GeoShape = new
                    {
                        Coordinates = elem["fields"]["geo_shape"]["coordinates"].Select(i => i.Select(j => j.Select(k => (double)k).ToArray()).ToArray()).ToArray(),
                        Type = (string)elem["fields"]["geo_shape"]["type"],
                    },
                    GeoPoint2d = elem["fields"]["geo_point_2d"].Select(i => (double)i).ToArray(),
                    Gisprod1GisAdoppAnnexationsCasenumber = (string)elem["fields"]["gisprod1_gis_adopp_annexations_casenumber"],
                    Gisprod1GisAdoppAnnexationsRow = (int)elem["fields"]["gisprod1_gis_adopp_annexations_row"],
                    Gisprod1GisAdoppAnnexationsDeedacres = (double)elem["fields"]["gisprod1_gis_adopp_annexations_deedacres"],
                    Gisprod1GisAdoppAnnexationsTotalacres = (double)elem["fields"]["gisprod1_gis_adopp_annexations_totalacres"],
                    ShapeStlength = (double)elem["fields"]["shape_stlength"],
                    Gisprod1GisAdoppAnnexationsPin = (string)elem["fields"]["gisprod1_gis_adopp_annexations_pin"],
                    Gisprod1GisAdoppAnnexationsOwner = (string)elem["fields"]["gisprod1_gis_adopp_annexations_owner"],
                    ShapeStarea = (double)elem["fields"]["shape_starea"],
                    Gisprod1GisAdoppAnnexationsStatus = (string)elem["fields"]["gisprod1_gis_adopp_annexations_status"],
                },
                Geometry = new
                {
                    Type = (string)elem["geometry"]["type"],
                    Coordinates = elem["geometry"]["coordinates"].Select(i => (double)i).ToArray(),
                },
                RecordTimestamp = (DateTime)elem["record_timestamp"],
            }).ToList();

            var expression = data[0].Fields.GeoShape.Coordinates[0][0][0];
            Console.WriteLine(expression);
        }
    }
}
