﻿using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net.Http;

namespace task_2
{
    class Task4_8
    {
        HttpClient client;
        string responseBody;
        

        public Task4_8()
        {
            client = new HttpClient();
            Get();
        }

        public async void Get()
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync("https://data.townofcary.org/api/records/1.0/search/?dataset=building-points&q=&facet=building_type&facet=building_sub_type&facet=bldgstyle&facet=yearbuilt&facet=storyheight&facet=basement&facet=utilities");
                responseBody = await response.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine(e);
            }

            JObject objectData = JObject.Parse(responseBody);

            var data = objectData["records"].Select(elem => new {
                DatasetID = (string)elem["datasetid"],
                Recordid = (string)elem["recordid"],
                Fields = new
                {
                    Utilities = (string)elem["fields"]["utilities"],
                    building_sub_type = (string)elem["fields"]["building_sub_type"],
                    GeoShape = new
                    {
                        Coordinates = elem["fields"]["geo_shape"]["coordinates"].Select(i => (double)i).ToArray(),
                        Type = (string)elem["fields"]["geo_shape"]["type"],
                    },
                    Bldgtyle = (string)elem["fields"]["bldgstyle"],
                    Phyzip = (string)elem["fields"]["phyzip"],
                    Location = (string)elem["fields"]["location"],
                    Additionyr = (string)elem["fields"]["additionyr"],
                    YearBuilt = (string)elem["fields"]["yearbuilt"],
                    StreetNumber = (string)elem["fields"]["streetnumber"],
                    ExtWall = (string)elem["fields"]["extwall"],
                    StreetName = (string)elem["fields"]["streetname"],
                    BathRooms = (string)elem["fields"]["bathrooms"],
                    Effectiveyr = (string)elem["fields"]["effectiveyr"],
                    Remodelyr = (string)elem["fields"]["remodelyr"],
                    Pin = (string)elem["fields"]["pin"],
                    BldgValue = (int)elem["fields"]["bldgvalue"],
                    Rooms = (int)elem["fields"]["rooms"],
                    RealID = (string)elem["fields"]["realid"],
                    GeoPoint2d = elem["fields"]["geo_point_2d"].Select(i => (double)i).ToArray(),
                    DtoryHeight = (string)elem["fields"]["storyheight"],
                    DtreetType = (string)elem["fields"]["streettype"],
                    Owner = (string)elem["fields"]["owner"],
                    OwnerAdd1 = (string)elem["fields"]["owneradd1"],
                    ownerAdd2 = (string)elem["fields"]["owneradd2"],
                    BuildingType = (string)elem["fields"]["building_type"],
                    Basement = (string)elem["fields"]["basement"],
                    PhyCity = (string)elem["fields"]["phycity"],
                    Sqft = (int)elem["fields"]["sqft"],
                    PercentBasement = (int)elem["fields"]["percentbasement"],
                    Units = (int)elem["fields"]["units"],
                },
                Geometry = new
                {
                    Type = (string)elem["geometry"]["type"],
                    Coordinates = elem["geometry"]["coordinates"].Select(i => (double)i).ToArray(),
                },
                RecordTimestamp = (DateTime)elem["record_timestamp"],
            }).ToList();

            // task5
            //var expression = data.Where(i => i.Fields.Owner.Contains("JALI"));

            // task6
            //var expression = data.Where(i => 
            //(i.Fields.Basement.StartsWith("No") && 
            //i.Fields.Units >= 1) || 
            //(i.Fields.Location.EndsWith("PL") &&
            //Int32.Parse(i.Fields.StreetNumber) > 1000));

            // task7
            //var expression = data.GroupBy(i => i.Fields.ExtWall).Select(g => g.Count());

            // task8
            //var expression = data.OrderByDescending(p => p.Fields.ExtWall.Length);

            ////Console.WriteLine(expression);

            //foreach (var elem in expression)
            //{
            //    Console.WriteLine(elem.Fields.ExtWall);
            //}
        }
    }
}
