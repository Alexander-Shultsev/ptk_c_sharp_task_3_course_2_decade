﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_2
{
    class Task9
    {
        StreamReader reader;

        string dataString;
        JArray dataArray;

        public Task9()
        {
            try
            {
                // objects
                dataArray = ParseData("C:\\Users\\ptk12\\Downloads\\data\\objects.json");

                var objects = dataArray.Select(elem => new
                {
                    ObjectID = (Guid)elem["ObjectID"],
                    TimeZoneID = (Guid)elem["TimeZoneID"],
                    TypeObjectID = (Guid)elem["TypeObjectID"],
                    CreatedOn = (DateTime)elem["CreatedOn"],
                    ModifiedOn = (DateTime?)elem["ModifiedOn"],
                }).ToList();

                // typeObjects
                dataArray = ParseData("C:\\Users\\ptk12\\Downloads\\data\\typeobjects.json");

                var typeObjects = dataArray.Select(elem => new
                {
                    TypeObjectID = (Guid)elem["TypeObjectID"],
                    TypeObject = (int)elem["TypeObject"],
                    Name = (string)elem["Name"],
                    Tvr = (int?)elem["tvr"],
                    GroupObjectCode = (int)elem["GroupObjectCode"],
                }).ToList();

                // typeZones
                dataArray = ParseData("C:\\Users\\ptk12\\Downloads\\data\\timezones.json");

                var typeZones = dataArray.Select(elem => new
                {
                    TimeZoneID = (Guid)elem["TimeZoneID"],
                    TimeZoneCode = (int)elem["TimeZoneCode"],
                    Name = (string)elem["Name"],
                    Bias = (int)elem["Bias"],
                }).ToList();

                var result = from objectElem in objects
                             join typeObjectsElem in typeObjects
                             on objectElem.TypeObjectID equals typeObjectsElem.TypeObjectID
                             join typeZoneElem in typeZones
                             on objectElem.TimeZoneID equals typeZoneElem.TimeZoneID
                             select new
                             {
                                 ObjectID = objectElem.ObjectID,
                                 ObjectCreatedOn = objectElem.CreatedOn,
                                 ObjectModifiedOn = objectElem.ModifiedOn,
                                 TypeObject = new
                                 {
                                     TypeObject = typeObjectsElem.TypeObject,
                                     Name = typeObjectsElem.Name,
                                     Tvr = typeObjectsElem.Tvr,
                                     GroupObjectCode = typeObjectsElem.GroupObjectCode,
                                 },
                                 TimeZone = new
                                 {
                                     TimeZoneCode = typeZoneElem.TimeZoneCode,
                                     Name = typeZoneElem.Name,
                                     Bias = typeZoneElem.Bias,
                                 },
                             };

                // 13
                //var countByGroup = result.GroupBy(a => a.TypeObject)
                //    .Select(b => new 
                //    {
                //        Name = b.Key, 
                //        TypeObject = b.GroupBy(c => c.TimeZone)
                //        .Select(elem => new 
                //        { 
                //            Name = elem.Key,
                //            Count = elem.Count()
                //        }).ToList()
                //    }).ToList();

                var countByGroup = result.GroupBy(group => new { group.TypeObject, group.TimeZone })
                    .Select(elem => new
                    {
                        elem.Key.TypeObject,
                        elem.Key.TimeZone,
                        Count = elem.Count(),
                    }).ToList();


                //Console.WriteLine(countByGroup[0]);


                foreach (var typeObject in countByGroup)
                {
                    Console.WriteLine("TypeObject - " + typeObject.TypeObject);
                    Console.WriteLine("TypeObject - " + typeObject.TimeZone);
                    Console.WriteLine("TypeObject - " + typeObject.Count);
                }

                //foreach (var typeObject in countByGroup)
                //{
                //    Console.WriteLine(typeObject.Name);
                //    foreach (var typeZone in typeObject.TypeObject)
                //    {
                //        Console.WriteLine(typeZone.Name);
                //        Console.WriteLine(typeZone.Count);
                //    }
                //}
            }
            catch (Exception e)
            {
                Console.WriteLine($"Ошибка - {e}"); 
            }
        }

        private JArray ParseData(string link)
        {
            reader = new StreamReader(link);
            dataString = reader.ReadToEnd();
            
            return JArray.Parse(dataString);
        }
    }
}
